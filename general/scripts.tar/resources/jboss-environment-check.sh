#!/bin/sh

#####################################
#
# jboss-environment-check.sh
# 
# Pre-install checks for OpenAM deployment 
# 
# COPYRIGHT Ericsson 2012
#
#####################################

# ============
# Global vars:
# ============

# Script name
SCRIPT_NAME=`basename $0`

echo "Running $SCRIPT_NAME"

# Check if jboss is running
if service jboss-eap status; then
	# TODO: improve this message
	echo "Jboss is running as expected, continuing"
else
	echo "JBoss appears to be offline, attempting to start it, please wait...."
	if service jboss-eap start && service jboss-eap status | grep pid; 
	then 
		echo "JBoss successfully started, installation continuing"; 
		echo "This was not an expected scenario, JBoss should have been running, other system errors may be present, installation is continuing but please check logs.."; 
	else
		echo "Unable to start JBoss, please check system, exiting installation of SSO"
		exit 1;
	fi
fi

# Check That JBoss extensions/subsytem configured correctly -- webservices and jaxrs should not be present
if /opt/jboss-eap/bin/jboss-cli.sh --connect --commands="cd subsystem,ls" | grep -e 'jaxrs|webservices'; 
	then 
		echo "######################################################################################################"
		echo "Badly configured JBoss instance, jaxrs and webservices extension/subsystem should be removed for SSO"; 
		echo "Exiting installation"
		echo "######################################################################################################"
		exit 1;
	else echo "JBoss extension/subsytem configuration test: passed, installation continuing"; 
fi

# Check that JBoss module.xml has been updated wit x.509 certificate
if cat /opt/jboss-eap/modules/sun/jdk/main/module.xml | grep x509> /dev/null ; 

	then 
		echo "sun.jdk.main.main.module.xml x509 configuration test: passed, installation continuing "; 
	else
		echo "######################################################################################################" 
		echo "sun.jdk.main.main.module.xml does not declare sun/security/x509 as a dependency"; 
		echo "Exiting installation"
		echo "######################################################################################################"
		exit 1;
fi


