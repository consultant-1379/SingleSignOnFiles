#!/bin/bash

#####################################
#
# Post-deploy steps for JBoss "app":
#
# Initial OpenAM configuration:
#       - Declaring the home directory of OpenAM
#       - Defining the LDAP details
#
# COPYRIGHT Ericsson 2013
#
#####################################
set -x
# Script name
SCRIPT_NAME=`basename $0`

. ../../../conf/site-configuration.conf
# Use common LITP variables
. ../../../conf/litp-vars.conf

# use common global variables
. ../../../conf/env-vars.conf

# Set the JAVA_HOME variable to jre 1.6 - this is installed
# in it's own directory that we will reference explicitly
SSO_INSTALL_JAVA_HOME=$SSO_HOME/resources/jre/jre1.6.0_38

# The OpenAM auto-config script needs a conf file
SSO_CONFIGURATOR_OPTIONS=../../../conf/configurator.conf

# Where the configurator tool lives
SSO_CONFIGURATOR_HOME=$SSO_HOME/resources/openam-tools/config

# Set the password - NEEDS SECURITY AUDIT!
PASSWD=h31md477R

echo $PASSWD > $SSO_HOME/resources/pass.txt
chmod 400 $SSO_HOME/resources/pass.txt

# Define the configurator options
cat << EOF > $SSO_CONFIGURATOR_OPTIONS
# Server properties, AM_ENC_KEY="" means generate random key
SERVER_URL=$AM_SERVER_URL
DEPLOYMENT_URI=$SSO_NAME-1.1.1
BASE_DIR=$SSO_FULL_SYMLINK
locale=en_US
PLATFORM_LOCALE=en_US
AM_ENC_KEY=
ADMIN_PWD=$PASSWD
AMLDAPUSERPASSWD=p071cyh31md477R
COOKIE_DOMAIN=$SSO_COOKIE_DOMAIN

# Embedded configuration data store
DATA_STORE=embedded
DIRECTORY_SSL=SIMPLE
DIRECTORY_SERVER=$SSO_MACHINE_NAME
DIRECTORY_PORT=51389
DIRECTORY_ADMIN_PORT=4445
DIRECTORY_JMX_PORT=1699
ROOT_SUFFIX=dc=opensso,dc=java,dc=net
DS_DIRMGRDN=cn=Directory Manager
DS_DIRMGRPASSWD=c0nf1gh31md477R
EOF
cat $SSO_CONFIGURATOR_OPTIONS

# echo "Waiting"
# sleep 2
# run the command
echo "Running $SSO_INSTALL_JAVA_HOME/bin/java -jar $SSO_CONFIGURATOR_HOME/configurator.jar -f $SSO_CONFIGURATOR_OPTIONS"
$SSO_INSTALL_JAVA_HOME/bin/java -jar $SSO_CONFIGURATOR_HOME/configurator.jar -f $SSO_CONFIGURATOR_OPTIONS
echo "Done running $SSO_INSTALL_JAVA_HOME/bin/java -jar $SSO_CONFIGURATOR_HOME/configurator.jar -f $SSO_CONFIGURATOR_OPTIONS"





##############################
#
# Main configuration of OpenAM
#
##############################
set -x
. ../../../conf/site-configuration.conf
# Use common LITP variables
. ../../../conf/litp-vars.conf

# use common global variables
. ../../../conf/env-vars.conf

# Set up JAVA_HOME
export JAVA_HOME=$SSO_HOME/resources/jre

# Location of the admin tool
SSO_SSOADM_HOME=$SSO_HOME/resources/openam-tools/admin

echo "Setting up ssoadm tool"
cd $SSO_SSOADM_HOME
./setup -p $SSO_FULL_SYMLINK -d $SSO_SSOADM_HOME/debug -l $SSO_SSOADM_HOME/log

echo "Running ssoadm batch commands"
$SSO_SSOADM_HOME/heimdallr-1.1.1/bin/ssoadm do-batch -u amadmin -f $SSO_HOME/resources/pass.txt -Z $SSO_SSOADM_HOME/openam-batch.conf --batchstatus $SSO_SSOADM_HOME/openam-batch.log --continue

echo "$SSO_SSOADM_HOME/openam-batch.log:"
cat $SSO_SSOADM_HOME/openam-batch.log

echo "Running extra 'create-agent' command"
$SSO_SSOADM_HOME/heimdallr-1.1.1/bin/ssoadm create-agent -e FREJA \
        -u amadmin \
        -f $SSO_HOME/resources/pass.txt \
        -b FREJA-agent \
        -t WebAgent \
        -s $AM_SERVER_URL/heimdallr-1.1.1 \
        -g $AGENT_SERVER_URL \
        -a userpassword=$SSO_AGENT_PASSWORD
