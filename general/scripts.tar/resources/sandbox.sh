#!/bin/sh
FORCE_ENABLED=0

for arg in $@; do
	if [ $arg = "-f" ]; then
		echo $arg
		break
	fi
done