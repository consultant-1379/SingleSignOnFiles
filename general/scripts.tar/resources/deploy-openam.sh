#!/bin/sh

#####################################
#
# deploy-openam.sh
# 
# Script for deploying OpenAM war file
# and/or checking deployment 
# 
# COPYRIGHT Ericsson 2012
#
#####################################

# ============
# Global vars:
# ============

JBOSS_HOST=192.168.0.43
JBOSS_ADMIN_PORT=9999
JBOSS_HOME=/opt/jboss-eap

JBOSS_COMMAND_ROOT="$JBOSS_HOME/bin/jboss-cli.sh --controller=$JBOSS_HOST:$JBOSS_ADMIN_PORT --connect"

# Location of war file should be $1
SSO_WAR_FILE=$1

# For testing only
SSO_NAME=dummy-webapp

# FORCE_REDEPLOY=0

# Connect to jboss cli and check if $SSO_NAME.war is deployed and store
# the result in a string
echo "Checking deployment status (with command: $JBOSS_COMMAND_ROOT --command=\"deploy -l\" | grep $SSO_NAME)"
DEPLOY_RESULT=`$JBOSS_COMMAND_ROOT --command="deploy -l" | grep $SSO_NAME`

# String follows these headers:
#
# NAME             RUNTIME-NAME     ENABLED STATUS

if [ -n "$DEPLOY_RESULT" ]; then
	echo "Deployment exists"
	DEPLOYMENT_NAME=`echo $DEPLOY_RESULT | awk '{print $1}'`
 

#	# grab the relevant columns into variables
#	# TODO: remove code duplication somehow

#	DEPLOYMENT_ENABLED=`echo $DEPLOY_RESULT | awk '{print $3}'`
#	DEPLOYMENT_STATUS=`echo $DEPLOY_RESULT | awk '{print $4}'`
#
#	# if the "ENABLED" column is true
#	if [ $DEPLOYMENT_ENABLED = "false" ]; then
#		# enable the deployed war file
#		$JBOSS_HOME/bin/jboss-cli.sh --controller=$JBOSS_HOST:$JBOSS_ADMIN_PORT --command="deploy --name=$SSO_WAR_FILE"
#	fi
#
#	if [ $DEPLOYMENT_STATUS != "OK"]; then
#		# Force a redeployment
#		$JBOSS_HOME/bin/jboss-cli.sh --controller=$JBOSS_HOST:$JBOSS_ADMIN_PORT --command="deploy --force $SSO_WAR_FILE"
#	fi
# else
	# Deploy war file as normal, will be enabled by default
#	$JBOSS_HOME/bin/jboss-cli.sh --controller=$JBOSS_HOST:$JBOSS_ADMIN_PORT --command="deploy $SSO_WAR_FILE"

	
	# Undeploy existing deployment
	echo "Undeploying existing application $DEPLOYMENT_NAME"
	$JBOSS_COMMAND_ROOT --command="undeploy $DEPLOYMENT_NAME"
fi

# Deploy the war file passed in as command line argument
echo "Deploying $1"
$JBOSS_COMMAND_ROOT --command="deploy $1"
echo "Done"