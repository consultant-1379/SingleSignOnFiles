#!/bin/sh

#####################################
#
# litp-environment-check.sh
# 
# Pre-install checks for OpenAM deployment 
# 
# COPYRIGHT Ericsson 2012
#
#####################################

# ============
# Global vars:
# ============

# Get vars from external conf file
. env-vars.conf

# Script name
SCRIPT_NAME=`basename $0`

# Get the current time to the second
# 
# Format is YYYY-MM-DD-hhmmss
NOW=`date "+%F-%H%M%S"`

# Flag to check if -f/--force option was invoked on the command line
FORCE_ENABLED=0


# ====================
# Function definitions
# ====================

# Helper function to show usage
show_help()
{
	echo "Usage: $SCRIPT_NAME [OPTIONS]"
	printf "\nRunning the command with no arguments prints this help.\n\n"
	echo "Options:"
	printf "\t-h, --help\t\tPrint this help\n"
	printf "\t-f, --force\t\tForce creation of new configuration directory (appended with current timestamp)\n\n"
}


# Command-line argument parsing
for arg in $@; do
	if [ $arg = "-f" ] || [ $arg = "--force" ]; then
		FORCE_ENABLED=1
	fi
	if [ $arg = "-h" ] || [ $arg = "--help" ]; then
		show_help
		exit 0;
	fi
done

if [ $FORCE_ENABLED = 0 ]; then
	echo "Option -f (force mode) not selected. Running in safe mode."
else
	echo "Force mode selected"
fi

# First check if there is an instance of OpenAM running. This is
# determined by searching for the string $SSO_NAME in the output
# of the lsof command
#
# TODO: reduce output of lsof command with it's own options rather than
# relying solely on grep
if lsof | grep $SSO_NAME > /dev/null; then
	# TODO: improve this message
	echo "Heimdallr SSO is already running. Please stop it in the future"
	echo "Script will continue. Unpredictable events may occur."
	# exit 1;
fi

# Check if SSO home directory directory exists
echo "Checking if $SSO_HOME exists..."
if [ -d "$SSO_HOME" ]; then
	echo "$SSO_HOME exists, no need to create one"
else 
	echo "No $SSO_HOME folder detected, creating one"
	mkdir -p $SSO_HOME
	echo "$SSO_HOME created" 
fi

# Check if actual configuration directory exists
echo "Checking if $SSO_CONFIG_HOME exists..."
if [ -d "$SSO_CONFIG_HOME" ]; then
	echo "$SSO_CONFIG_HOME exists"
else
	echo "No $SSO_CONFIG_HOME detected, creating one"
	mkdir -p $SSO_CONFIG_HOME
	echo "$SSO_CONFIG_HOME created" 
fi

# Get the current time to the second and keep the declaration
# as close to the first use as possible
# 
# Format is YYYY-MM-DD-hhmmss
NOW=`date "+%F-%H%M%S"`

# Check if OpenAM config exists
echo "Checking if previous configurations exist"
if [ $SSO_CONFIG_HOME/$SSO_NAME\* ]; then
	if [ $FORCE_ENABLED = 0 ]; then
		# TODO: improve this message
		echo "Heimdallr configuration already exists, exiting."
		echo "Use -f option to override this"
		echo "WARNING: Using -f will replace existing configuration"
		exit 1;
	fi

	if [ -d $SSO_CONFIG_HOME/$SSO_NAME-$NOW ]; then
		# A configuration directory exists with the same
		# timestamp as we have now, an unexpected event has occurred
		echo "##############################################################################################"
		echo "Config directory exists with the same timestamp. Possible duplicate process running, exiting."
		echo "Please investigate and run again when safe to do so"
		echo "##############################################################################################"
		exit 1
	fi

	echo "Configuration exists, preparing to overwrite it"
else
	echo "No previous configurations exist"
fi

# We don't need to shutdown JBoss as we're creating a new folder
# and won't have issues with file locks etc. Afterwards, JBoss
# will need to be restarted for the changes to take effect
echo "Creating new configuration directory at $SSO_CONFIG_HOME/$SSO_NAME-$NOW"
mkdir -p $SSO_CONFIG_HOME/$SSO_NAME-$NOW

# Check if symlink exists
echo "Checking if symlink created"
if [ -L "$SSO_FULL_SYMLINK" ]; then
	echo "Link exists. Removing"
	rm -f $SSO_FULL_SYMLINK
fi
echo "Creating symlink: $SSO_FULL_SYMLINK links to $SSO_CONFIG_HOME/$SSO_NAME-$NOW"
ln -s $SSO_CONFIG_HOME/$SSO_NAME-$NOW $SSO_FULL_SYMLINK


# Change ownership of directories and symlink
# 
# This script is assumed to be run as root, therefore file/directory
# ownership needs to be changed regardless.
# This can be tested later with 'stat -c"%U:%G" $SSO_FULL_SYMLINK'
echo "Changing ownership of $SSO_FULL_SYMLINK to $JBOSS_USER:$JBOSS_GROUP"
chown -R $JBOSS_USER:$JBOSS_GROUP $SSO_FULL_SYMLINK
echo "Changing ownership of $SSO_CONFIG_HOME/$SSO_NAME-$NOW to $JBOSS_USER:$JBOSS_GROUP"
chown -R $JBOSS_USER:$JBOSS_GROUP $SSO_CONFIG_HOME/$SSO_NAME-$NOW

# TODO: Add proper system logging (logger -s)
# TODO: Create own file in /var/log?
# TODO: More meaningful console/log output
# TODO: Option to suppress console output