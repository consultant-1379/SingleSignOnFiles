#!/bin/sh

#####################################
#
# init-openam.sh
# 
# Script for deploying OpenAM war file
# and/or checking deployment 
# 
# COPYRIGHT Ericsson 2012
#
#####################################

# ============
# Global vars:
# ============
# . configurator.conf
. ./env-vars.conf

# Assume we have JRE 1.6 in a well known location
JAVA_HOME=$SSO_HOME/jre1.6

# location of options file
CONFIGURATOR_OPTIONS=$SSO_HOME/scripts/configurator.conf

# Location of OpenAM configurator
CONFIGURATOR_HOME=$SSO_HOME/tools/config

# test variables
echo $JAVA_HOME
echo $CONFIGURATOR_OPTIONS
echo $CONFIGURATOR_HOME
echo $SERVER_URL
echo $JBOSS_USER
echo $JBOSS_GROUP
echo $AM_SERVER_URL

# Create the directory if needed
#if [ ! -d $CONFIGURATOR_HOME ]; then
#	mkdir -p $CONFIGURATOR_HOME
#fi

# Run the configurator jar
#$JAVA_HOME/bin/java -jar $CONFIGURATOR_HOME/configurator.jar -f $CONFIGURATOR_OPTIONS